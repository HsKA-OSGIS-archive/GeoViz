<?php

$user = 'postgres';
$password = 'postgis';
$host = 'localhost';
$port = '5432';
$dbname = 'sandwikimap';

?>